import request from "supertest";
import { expect } from "chai";
import { it, describe } from "mocha";
import { createApp } from "../app";

describe("Links Services", () => {

    it("HTTP GET /links should return all links", (done) => {

        (async () => {
            const app = await createApp();
            request(app)
                    .get("/links")
                    .expect(200)
                    .expect(function(res) {
                        expect(res.body[1].title).to.eq("Services link");
                    })
                    .end(function(err, res) {
                        if (err) throw err;
                        done();
                    });
        })();

    });

});

