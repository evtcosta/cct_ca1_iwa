import { expect } from "chai";
import { it, describe } from "mocha";
import { getHandlers } from "../src/backend/controllers/links_controller";
import { Links } from "../src/backend/entities/links";

describe("Link Controller", () => {

    it("Should be able to get a link by ID", () => {
        const fakeLink: Links = {
            id: 1,
            title: "Jobs link",
        };
        const fakeRequest: any = {
            params: {
                id: 1
            }
        };
        const fakeResponse: any = {
            json: (link: Links) =>
                expect(link.title).to.eq(fakeLink.title)
        };
        const fakeRepository: any = {
            findOne: (id: number) => {
                expect(id).to.eq(fakeLink.id);
                return Promise.resolve(fakeLink);
            }
        };
        const handlers = getHandlers(fakeRepository);
        handlers.getLinkByIDHandler(fakeRequest, fakeResponse);
    });

});