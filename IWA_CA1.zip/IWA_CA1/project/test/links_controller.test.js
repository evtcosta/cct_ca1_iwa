"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var chai_1 = require("chai");
var mocha_1 = require("mocha");
var links_controller_1 = require("../src/backend/controllers/links_controller");
mocha_1.describe("Link Controller", function () {
    mocha_1.it("Should be able to get a link by ID", function () {
        var fakeLink = {
            id: 1,
            title: "Jobs link",
        };
        var fakeRequest = {
            params: {
                id: 1
            }
        };
        var fakeResponse = {
            json: function (link) {
                return chai_1.expect(link.title).to.eq(fakeLink.title);
            }
        };
        var fakeRepository = {
            findOne: function (id) {
                chai_1.expect(id).to.eq(fakeLink.id);
                return Promise.resolve(fakeLink);
            }
        };
        var handlers = links_controller_1.getHandlers(fakeRepository);
        handlers.getLinkByIDHandler(fakeRequest, fakeResponse);
    });
});
