import express from "express";
import bodyParser from "body-parser";
import { createDbConnection } from "./db";
import { getCommentController } from "./src/backend/controllers/comment_controller";
import { getAuthController } from "./src/backend/controllers/auth_controller";
import { getUserController } from "./src/backend/controllers/user_controller";
import { getLinksController } from "./src/backend/controllers/links_controller";


export async function createApp() {

    // Create db connection
    await createDbConnection();

    // Creates app
    const app = express();

    // Server config to be able to send JSON
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

    // Declare main path
    app.get("/", (req, res) => {
        res.send("This is the home page!");
    });

    // Declare controllers
    const commentController = getCommentController();
    const linksController = getLinksController();
    const usersController = getUserController();
    const authController = getAuthController();
    app.use("/auth", authController);
    app.use("/users", usersController);
    app.use("/links", linksController);
    app.use("/comment", commentController);

    return app;
}