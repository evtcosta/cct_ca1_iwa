"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typeorm_1 = require("typeorm");
var links_1 = require("../entities/links");
function getLinksRepository() {
    var connection = typeorm_1.getConnection();
    var linksRepository = connection.getRepository(links_1.Links);
    return linksRepository;
}
exports.getLinksRepository = getLinksRepository;
