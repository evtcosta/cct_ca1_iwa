import * as express from "express";
import { getUserRepository } from "../repositories/user_repository";
import { getLinksRepository } from "../repositories/links_repository";
import { getCommentRepository } from "../repositories/comment_repository";
import * as joi from "joi";

export function getUserController() {

    const userRepository = getUserRepository();
    const linksRepository = getLinksRepository();
    const commentRepository = getCommentRepository();
    const router = express.Router();

    const userDetailsSchema = {
        email: joi.string().email(),
        password: joi.string()
    };

    // HTTP POST http://localhost:8080/users/
    router.post("/api/v1/users", (req, res) => {
        (async () => {
            const newUser = req.body;
            const result = joi.validate(newUser, userDetailsSchema);
            if (result.error) {
                res.status(400).send();
            } else {
                const user = await userRepository.save(newUser);
                res.json({ ok: "ok" }).send();
            }
        })();
    });

    router.get("/api/v1/users/:id", (req, res) => {
        (async () => {
            const id = req.params.id;
            const result = joi.validate(id, userDetailsSchema);
            if (result.error) {
                res.status(404).send();
            } else {
                const links = await linksRepository.findOne(id);
                const comment = await commentRepository.findOne(id);
                const user = await userRepository.findOne(id);
                res.json([links,comment,user]);
            }    
            
        })();
    });


    return router;
}