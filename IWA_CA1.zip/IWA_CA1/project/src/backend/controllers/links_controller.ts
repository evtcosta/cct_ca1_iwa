import * as express from "express";
import { getLinksRepository } from "../repositories/links_repository";
import { getCommentRepository } from "../repositories/comment_repository";
import { getVoteRepository } from "../repositories/vote_repository";
import * as joi from "joi";
import { Repository } from "typeorm";
import { Links } from "../entities/links";

export function getHandlers(linkRepo: Repository<Links>) {

    const getLinkByIDHandler = (req: express.Request, res: express.Response) => {
        (async () => {
            const id = req.params.id;
            const links = await linkRepo.findOne(id);
            res.json(links);
        })();
    };

    const getLinkByTitleHandler = (req: express.Request, res: express.Response) => {
        (async () => {
            const title = req.params.title;
            const links = await linkRepo.find({ title: title });
            res.json(links);
        })();
    };

    return {
        getLinkByIDHandler: getLinkByIDHandler,
        getLinkByYearHandler: getLinkByTitleHandler
    }; 
}

export function getLinksController() {

    const linksRepository = getLinksRepository();
    const commentRepository = getCommentRepository();
    const voteRepository = getVoteRepository();
    const router = express.Router();

    const userDetailsSchema = {
        email: joi.string().email(),
        password: joi.string()
    };

    // http://localhost:8080/links/
    router.get("/", (req, res) => {
        (async () => {
            const links = await linksRepository.find();
            res.json(links);
        })();
    });

    router.get("/api/v1/links", (req, res) => {
        (async () => {
            const links = await linksRepository.find();
            res.json(links);
        })();
    });

    router.get("/api/v1/links/:id", (req, res) => {
        (async () => {
            const id = req.params.id;
            const links = await linksRepository.findOne(id);
            const comment = await commentRepository.findOne(id);
            res.json([links,comment]);
        })();
    });

    router.post("/api/v1/links", (req, res) => {
        (async () => {
            const newLink = req.body;
            const result = joi.validate(req.body, userDetailsSchema);
            if (result.error) {
                res.status(400).send({ msg: "Link is not valid!" });
            } else {
                const links = await linksRepository.save(newLink);
                res.json(links);
            }

        })();


    });

    router.delete("/api/v1/links/:id", (req, res) => {
        (async () => {
            const id = req.params.id;
            const result = joi.validate(req.body, userDetailsSchema);
            if(result.error){
                res.status(401).send({ msg: "Unauthorized access" });
            }else {
                const links = await linksRepository.delete(id);
                res.json(links);
            }
                     

        })();


    });

    router.post("/api/v1/links/:id/upvote", (req, res) => {
        (async () => {
            const id = req.params.id;
            const upvote = req.body;
            const result = joi.validate(req.body, userDetailsSchema);
            if(result.error){
                res.status(403).send({ msg: "You are not allowed to vote again" });
            }else {
                const vote = await voteRepository.save(id, upvote);
                const links = await linksRepository.save(id);
                res.json([links, vote]);
            }
                     

        })();
        

    });

    router.post("/api/v1/links/:id/downvote", (req, res) => {
        (async () => {
            const id = req.params.id;
            const downvote = req.body;
            const result = joi.validate(req.body, userDetailsSchema);
            if(result.error){
                res.status(403).send({ msg: "You are not allowed to vote again" });
            }else {
                const vote = await voteRepository.save(id, downvote);
                const links = await linksRepository.save(id);
                res.json([links, vote]);
            }
                     

        })();
        

    });

    

    return router;
}