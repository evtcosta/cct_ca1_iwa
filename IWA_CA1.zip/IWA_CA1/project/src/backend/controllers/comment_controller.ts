import { getCommentRepository } from "../repositories/comment_repository";
import * as express from "express";
import * as joi from "joi";
import { Comments } from "../entities/comment";

export function getCommentController() {

    const commentRepository = getCommentRepository();
    const router = express.Router();

    const userDetailsSchema = {
        email: joi.string().email(),
        password: joi.string()
    };

    router.post("//api/v1/comment", (req, res) => {
        (async () => {
            const newComment = req.body;
            const comment = await commentRepository.save(newComment);
            res.json(comment);
        })();
    });

    router.patch("/api/v1/comment/:id", (req, res) => {
        (async () => {
            const id = req.params.id;
            const updatedComment = req.body
            const result = joi.validate(req.body, userDetailsSchema);
            if(result.error){
                res.status(400).send({ msg: "Unauthorized access" });
            } else {
                const match = await commentRepository.findOne(id);
                if (match === undefined) {
                    res.status(404).send({ msg: "Comment not found" });
                } else {
                    const comment = await commentRepository.save(updatedComment);
                    res.json(comment);
                }
                
            }
                     

        })();


    });

    router.delete("/api/v1/comment/:id", (req, res) => {
        (async () => {
            const id = req.params.id;
            const result = joi.validate(req.body, userDetailsSchema);
            if(result.error){
                res.status(400).send({ msg: "Unauthorized access" });
            } else {
                const match = await commentRepository.findOne(id);
                if (match === undefined) {
                    res.status(404).send({ msg: "Comment not found" });
                } else {
                    const comment = await commentRepository.delete(id);
                    res.json(comment);
                }
                
            }
                     

        })();


    });

    return router;
}