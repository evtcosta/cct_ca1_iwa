import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Comments {
    @PrimaryGeneratedColumn()
    public id!: number;
    @Column()
    public commentContent!: string;
}
