import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Vote {
    @PrimaryGeneratedColumn()
    public id!: number;
    @Column()
    public isPositive!: boolean;
}