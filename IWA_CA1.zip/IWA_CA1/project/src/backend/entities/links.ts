import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Links {
    @PrimaryGeneratedColumn()
    public id!: number;
    @Column()
    public title!: string;
}