// Reads all links
(async () => {
    const response = await fetch(
        "http://localhost:8080/links",
        {
            method: "GET"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Reads one link and its comments by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/links/1",
        {
            method: "GET"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Creates a new link
(async () => {
    const response = await fetch(
        "http://localhost:8080/links",
        {
            method: "POST"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Deletes a link by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/links/1",
        {
            method: "DELETE"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Upvotes a link by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/links/1/upvote",
        {
            method: "POST"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Downvotes a link by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/links/1/downvote",
        {
            method: "POST"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Reads the user details and validate it
(async () => {
    const response = await fetch(
        "http://localhost:8080/auth/login",
        {
            method: "POST"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Creates a new user account
(async () => {
    const response = await fetch(
        "http://localhost:8080/users",
        {
            method: "POST"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Reads one link and its comments by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/users/1",
        {
            method: "GET"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Creates a new comment
(async () => {
    const response = await fetch(
        "http://localhost:8080/comment",
        {
            method: "POST"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Updates the content of comment by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/comment/1",
        {
            method: "PATCH"
        }
    );
    const json = await response.json();
    console.log(json);
})();

// Deletes a comment by ID
(async () => {
    const response = await fetch(
        "http://localhost:8080/comment/1",
        {
            method: "DELETE"
        }
    );
    const json = await response.json();
    console.log(json);
})();